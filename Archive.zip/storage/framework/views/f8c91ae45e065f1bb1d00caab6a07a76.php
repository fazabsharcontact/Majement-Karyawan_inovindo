<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-6">
        <div class="bg-white rounded-lg shadow p-6 space-y-8">
            <div class="flex justify-between items-center mb-6">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">Manajemen Pengajuan Cuti</h2>
            </div>

            <!-- Notifikasi -->
            <?php if(session('success')): ?>
                <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            
            <div class="bg-gray-50 rounded-lg border border-gray-200 p-6">
                <h3 class="text-lg font-semibold text-gray-700 mb-2">Pengaturan Cuti Tahunan</h3>
                <p class="text-sm text-gray-600 mb-4">
                    Gunakan tombol ini sekali pada awal tahun untuk mereset jatah cuti semua pegawai kembali menjadi 12.
                </p>
                <form action="<?php echo e(route('admin.cuti.resetTahunan')); ?>" method="POST"
                    onsubmit="return confirm('Apakah Anda yakin ingin mereset sisa cuti semua pegawai menjadi 12? Aksi ini tidak dapat dibatalkan.')">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="bg-gray-900 hover:bg-gray-800 text-white px-4 py-2 rounded-md shadow text-sm font-medium">
                        Reset Cuti Tahunan Sekarang
                    </button>
                </form>
            </div>

            <!-- Daftar Pengajuan Cuti -->
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Daftar Pengajuan Cuti</h3>
                </div>

                <form method="GET" class="flex flex-wrap items-center gap-3 mb-4">
                    <input type="text" name="search" placeholder="Cari nama pegawai..."
                        class="border-gray-300 rounded-md shadow-sm text-sm" value="<?php echo e(request('search')); ?>">
                    <select name="status" class="border-gray-300 rounded-md shadow-sm text-sm">
                        <option value="">Semua Status</option>
                        <option value="Diajukan" <?php if(request('status') == 'Diajukan'): ?> selected <?php endif; ?>>Diajukan</option>
                        <option value="Disetujui" <?php if(request('status') == 'Disetujui'): ?> selected <?php endif; ?>>Disetujui</option>
                        <option value="Ditolak" <?php if(request('status') == 'Ditolak'): ?> selected <?php endif; ?>>Ditolak</option>
                    </select>
                    <button type="submit"
                        class="bg-gray-900 hover:bg-gray-800 text-white px-4 py-2 rounded-md shadow text-sm">Filter</button>
                </form>

                <div class="overflow-x-auto">
                    <table class="min-w-full border border-gray-200 rounded">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="border-b px-4 py-2 text-left">Nama Pegawai</th>
                                <th class="border-b px-4 py-2 text-left">Tanggal Cuti</th>
                                <th class="border-b px-4 py-2 text-center">Durasi</th>
                                <th class="border-b px-4 py-2 text-left">Keterangan</th>
                                <th class="border-b px-4 py-2 text-center">Status</th>
                                <th class="border-b px-4 py-2 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $cutis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="border-b px-4 py-2">
                                        <div class="font-medium"><?php echo e($cuti->pegawai->nama ?? 'N/A'); ?></div>
                                        <div class="text-xs text-gray-500"><?php echo e($cuti->pegawai->jabatan->nama_jabatan ?? 'N/A'); ?></div>
                                    </td>
                                    <td class="border-b px-4 py-2 text-sm">
                                        <?php echo e(\Carbon\Carbon::parse($cuti->tanggal_mulai)->format('d M Y')); ?> -
                                        <?php echo e(\Carbon\Carbon::parse($cuti->tanggal_selesai)->format('d M Y')); ?>

                                    </td>
                                    <td class="border-b px-4 py-2 text-center text-sm font-medium">
                                        <?php echo e($cuti->durasi_hari_kerja); ?> hari
                                    </td>
                                    <td class="border-b px-4 py-2 text-sm"><?php echo e($cuti->keterangan); ?></td>
                                    <td class="border-b px-4 py-2 text-center">
                                        <?php if($cuti->status == 'Disetujui'): ?>
                                            <span class="px-2 py-1 text-xs font-semibold text-green-800 bg-green-100 rounded-full">Disetujui</span>
                                        <?php elseif($cuti->status == 'Ditolak'): ?>
                                            <span class="px-2 py-1 text-xs font-semibold text-red-800 bg-red-100 rounded-full">Ditolak</span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 text-xs font-semibold text-yellow-800 bg-yellow-100 rounded-full">Diajukan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="border-b px-4 py-2 text-center">
                                        <?php if($cuti->status == 'Diajukan'): ?>
                                            <div class="flex justify-center gap-2">
                                                <form action="<?php echo e(route('admin.cuti.updateStatus', $cuti->id)); ?>" method="POST" class="inline">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <input type="hidden" name="status" value="Disetujui">
                                                    <button type="submit" class="text-green-600 hover:text-green-900 text-sm font-medium">Setujui</button>
                                                </form>
                                                <span class="text-gray-300">|</span>
                                                <form action="<?php echo e(route('admin.cuti.updateStatus', $cuti->id)); ?>" method="POST" class="inline">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <input type="hidden" name="status" value="Ditolak">
                                                    <button type="submit" class="text-red-600 hover:text-red-900 text-sm font-medium">Tolak</button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-gray-400 text-sm">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-gray-500">Tidak ada pengajuan cuti yang cocok dengan filter.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <?php echo e($cutis->appends(request()->query())->links('vendor.pagination.tailwind')); ?>

                    </div>
                </div>
            </div>

            
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Rekapitulasi Sisa Cuti Pegawai</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full border border-gray-200 rounded">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="border-b px-4 py-2 text-left">Nama Pegawai</th>
                                <th class="border-b px-4 py-2 text-left">Jabatan</th>
                                <th class="border-b px-4 py-2 text-center">Sisa Cuti Tahunan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="border-b px-4 py-2 font-medium"><?php echo e($pegawai->nama); ?></td>
                                    <td class="border-b px-4 py-2 text-sm"><?php echo e($pegawai->jabatan->nama_jabatan ?? 'N/A'); ?></td>
                                    <td class="border-b px-4 py-2 text-center font-bold text-lg">
                                        <?php echo e($pegawai->sisaCuti->sisa_cuti ?? 12); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center py-4 text-gray-500">Tidak ada data pegawai.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <?php echo e($pegawais->appends(request()->query())->links('vendor.pagination.tailwind')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Management-Karyawan/resources/views/admin/cuti/index.blade.php ENDPATH**/ ?>