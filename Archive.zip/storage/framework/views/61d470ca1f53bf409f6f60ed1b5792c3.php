<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="pt-20 sm:pt-24 bg-slate-50">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">

            
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8 space-y-8">

                
                <section class="space-y-3">
                    <h2 class="text-lg font-semibold text-slate-900">Ringkasan Gaji Periode Saat Ini</h2>

                    <div class="flex flex-wrap gap-3 items-center">
                        <?php if($detail): ?>
                            <button
                                class="px-5 py-2.5 bg-blue-600 text-white font-medium rounded-lg shadow hover:bg-blue-700 transition flex items-center gap-2"
                                id="btnDetailGaji">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                    viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"
                                        d="M4 6h16M4 12h16M4 18h16" />
                                </svg>
                                Lihat Detail (<?php echo e($bulanNama[$bulan] ?? 'Bulan Error'); ?> <?php echo e($tahun); ?>)
                            </button>

                            <a href="<?php echo e(route('pegawai.gaji.unduh', $detail->id)); ?>" target="_blank"
                                class="px-5 py-2.5 bg-rose-600 text-white font-medium rounded-lg shadow hover:bg-rose-700 transition flex items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                    viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7"
                                        d="M12 4v16m8-8H4" />
                                </svg>
                                Unduh Slip Gaji PDF
                            </a>
                        <?php else: ?>
                            <p class="text-slate-500">Data gaji untuk periode ini belum tersedia.</p>
                        <?php endif; ?>
                    </div>
                </section>

                
                <div class="fixed inset-0 bg-black/40 backdrop-blur-sm hidden z-50 flex items-center justify-center"
                    id="popupDetailGaji">
                    <div class="bg-white w-full max-w-lg rounded-2xl shadow-lg border border-slate-200 p-6 animate-fadeIn">
                        <div class="flex justify-between items-center border-b pb-3">
                            <h3 class="text-xl font-semibold text-slate-900">
                                Detail Gaji: <?php echo e($bulanNama[$bulan] ?? ''); ?> <?php echo e($tahun); ?>

                            </h3>
                            <button id="closePopup"
                                class="text-slate-500 hover:text-slate-700 text-2xl leading-none">&times;</button>
                        </div>

                        <div class="mt-4 space-y-3 text-slate-700">
                            <?php if($detail): ?>

                                
                                <p class="flex justify-between font-medium">
                                    <span class="text-slate-600">Gaji Pokok:</span>
                                    <span>Rp <?php echo e(number_format($detail->gaji_pokok, 0, ',', '.')); ?></span>
                                </p>

                                
                                <div class="pt-2 border-t border-slate-200">
                                    <p class="font-semibold text-blue-600 mb-1">Penerimaan</p>
                                    <?php $__currentLoopData = $detail->tunjanganDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="text-sm flex justify-between ml-2">
                                            <span><?php echo e($t->masterTunjangan->nama_tunjangan); ?></span>
                                            <span>Rp <?php echo e(number_format($t->jumlah, 0, ',', '.')); ?></span>
                                        </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <p class="font-medium flex justify-between pt-2 border-t border-slate-200">
                                        <span>Total Tunjangan:</span>
                                        <span class="text-emerald-600">Rp
                                            <?php echo e(number_format($detail->total_tunjangan, 0, ',', '.')); ?></span>
                                    </p>
                                </div>

                                
                                <div class="pt-2 border-t border-slate-200">
                                    <p class="font-semibold text-rose-600 mb-1">Potongan</p>
                                    <?php $__currentLoopData = $detail->potonganDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="text-sm flex justify-between ml-2">
                                            <span><?php echo e($p->masterPotongan->nama_potongan); ?></span>
                                            <span>Rp <?php echo e(number_format($p->jumlah, 0, ',', '.')); ?></span>
                                        </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <p class="font-medium flex justify-between pt-2 border-t border-slate-200">
                                        <span>Total Potongan:</span>
                                        <span class="text-rose-600">Rp
                                            <?php echo e(number_format($detail->total_potongan, 0, ',', '.')); ?></span>
                                    </p>
                                </div>

                                
                                <p class="text-xl font-extrabold text-emerald-700 flex justify-between pt-4 border-t-2 border-emerald-200">
                                    <span>Gaji Bersih:</span>
                                    <span>Rp <?php echo e(number_format($detail->gaji_bersih, 0, ',', '.')); ?></span>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <form method="GET" class="flex flex-wrap gap-6 items-end">
                    <div>
                        <label class="block text-sm font-medium text-slate-600 mb-1">Tahun</label>
                        <select name="tahun"
                            class="rounded-lg border border-slate-300 px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                            <?php for($i = now()->year; $i >= 2020; $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($tahun == $i ? 'selected' : ''); ?>>
                                    <?php echo e($i); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-slate-600 mb-1">Bulan</label>
                        <select name="bulan"
                            class="rounded-lg border border-slate-300 px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                            <?php $__currentLoopData = $bulanNama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($bulan == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit"
                        class="px-5 py-2.5 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-500 transition">
                        Lihat Data
                    </button>
                </form>

                
                <section>
                    <h2 class="text-lg font-semibold text-slate-900 mb-3">Riwayat Gaji</h2>

                    <div class="overflow-x-auto rounded-xl border border-slate-200 shadow-sm">
                        <table class="min-w-full text-sm">
                            <thead class="bg-slate-100 text-slate-700 border-b border-slate-200">
                                <tr>
                                    <th class="px-4 py-3 text-left">Tahun</th>
                                    <th class="px-4 py-3 text-left">Bulan</th>
                                    <th class="px-4 py-3 text-left">Gaji Bersih</th>
                                    <th class="px-4 py-3 text-center">Aksi</th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-slate-200">
                                <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="hover:bg-slate-50 transition">
                                        <td class="px-4 py-3"><?php echo e($row->tahun); ?></td>
                                        <td class="px-4 py-3">
                                            <?php echo e($bulanNama[$row->bulan] ?? ''); ?>

                                        </td>
                                        <td class="px-4 py-3 font-semibold text-slate-800">
                                            Rp <?php echo e(number_format($row->gaji_bersih, 0, ',', '.')); ?>

                                        </td>
                                        <td class="px-4 py-3 text-center">
                                            <a href="<?php echo e(route('pegawai.gaji.unduh', $row->id)); ?>" target="_blank"
                                                class="px-3 py-1.5 bg-rose-500 text-white rounded-md text-xs font-semibold hover:bg-rose-600">
                                                Unduh PDF
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="px-4 py-4 text-center text-slate-500">
                                            Data riwayat gaji tidak ditemukan.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </section>

            </div>
        </div>
    </div>

    
    <script>
        document.getElementById("btnDetailGaji")?.addEventListener("click", () => {
            document.getElementById("popupDetailGaji").classList.remove("hidden");
        });

        document.getElementById("closePopup")?.addEventListener("click", () => {
            document.getElementById("popupDetailGaji").classList.add("hidden");
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Internship/Management-Karyawan/resources/views/pegawai/gaji/index.blade.php ENDPATH**/ ?>