<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Monitoring Kehadiran Pegawai
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="p-6">
        <div class="bg-white rounded-lg shadow p-6">

            
            <?php if(session('success')): ?>
                <div class="mb-4 p-3 rounded bg-green-100 text-green-700"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="mb-4 p-3 rounded bg-red-100 text-red-700"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            
            
            
            <form method="GET" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 items-end mb-6 pb-4 border-b">
                
                <div class="col-span-1 md:col-span-2 lg:col-span-2">
                    <label for="pegawai-select" class="block text-sm font-medium text-gray-700">Pegawai</label>
                    
                    <select name="pegawai_id" id="pegawai-select" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                        <option value="">Semua Pegawai</option>
                        <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php echo e(request('pegawai_id') == $p->id ? 'selected' : ''); ?>>
                                <?php echo e($p->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div>
                     <label for="bulan" class="block text-sm font-medium text-gray-700">Bulan</label>
                    <select name="bulan" id="bulan" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                        <?php $__currentLoopData = ['01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(request('bulan', now()->format('m')) == $key ? 'selected' : ''); ?>><?php echo e($val); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div>
                    <label for="tahun" class="block text-sm font-medium text-gray-700">Tahun</label>
                    <select name="tahun" id="tahun" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                        <?php for($i = now()->year; $i >= now()->year - 5; $i--): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('tahun', now()->year) == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                
                <div class="flex gap-2">
                    <button type="submit" class="w-full text-center bg-gray-900 hover:bg-gray-800 text-white px-4 py-2 rounded-md shadow">
                        Filter
                    </button>
                     <a href="<?php echo e(route('admin.kehadiran.index')); ?>" class="w-full text-center bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md shadow">
                        Reset
                    </a>
                </div>
            </form>

            
            <div class="mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Rekapitulasi Kehadiran</h3>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 text-center">
                    <?php
                        $total_hadir = $rekap->sum('total_hadir');
                        $total_terlambat = $rekap->sum('total_terlambat');
                        $total_sakit = $rekap->sum('total_sakit');
                        $total_izin = $rekap->sum('total_izin');
                        $total_absen = $rekap->sum('total_absen');
                    ?>
                    <div class="p-4 bg-green-50 rounded-lg"><div class="text-2xl font-bold text-green-700"><?php echo e($total_hadir); ?></div><div class="text-sm text-green-600">Hadir</div></div>
                    <div class="p-4 bg-yellow-50 rounded-lg"><div class="text-2xl font-bold text-yellow-700"><?php echo e($total_terlambat); ?></div><div class="text-sm text-yellow-600">Terlambat</div></div>
                    <div class="p-4 bg-blue-50 rounded-lg"><div class="text-2xl font-bold text-blue-700"><?php echo e($total_sakit); ?></div><div class="text-sm text-blue-600">Sakit</div></div>
                    <div class="p-4 bg-indigo-50 rounded-lg"><div class="text-2xl font-bold text-indigo-700"><?php echo e($total_izin); ?></div><div class="text-sm text-indigo-600">Izin</div></div>
                    <div class="p-4 bg-red-50 rounded-lg"><div class="text-2xl font-bold text-red-700"><?php echo e($total_absen); ?></div><div class="text-sm text-red-600">Absen</div></div>
                </div>
            </div>

            
            <div class="overflow-x-auto">
                <table class="min-w-full border border-gray-300 text-sm">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-2 border">Pegawai</th>
                            <th class="px-4 py-2 border">Tanggal</th>
                            <th class="px-4 py-2 border">Jam Masuk</th>
                            <th class="px-4 py-2 border">Jam Pulang</th>
                            <th class="px-4 py-2 border">Status</th>
                            <th class="px-4 py-2 border">Bukti</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $kehadiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 border"><?php echo e($row->pegawai->nama); ?></td>
                                <td class="px-4 py-2 border"><?php echo e(\Carbon\Carbon::parse($row->tanggal)->format('d M Y')); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($row->jam_masuk ? \Carbon\Carbon::parse($row->jam_masuk)->format('H:i') : '-'); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($row->jam_pulang ? \Carbon\Carbon::parse($row->jam_pulang)->format('H:i') : '-'); ?></td>
                                <td class="px-4 py-2 border text-center">
                                    <span class="px-2 py-1 rounded-full text-xs font-semibold
                                        <?php if($row->status == 'Hadir'): ?> bg-green-100 text-green-800
                                        <?php elseif($row->status == 'Terlambat'): ?> bg-yellow-100 text-yellow-800
                                        <?php elseif($row->status == 'Sakit'): ?> bg-blue-100 text-blue-800
                                        <?php elseif($row->status == 'Izin'): ?> bg-indigo-100 text-indigo-800
                                        <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                                        <?php echo e($row->status); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-2 border text-center">
                                    <?php if($row->bukti): ?>
                                        <a href="<?php echo e(route('admin.kehadiran.downloadBukti', $row->id)); ?>" class="text-blue-500 hover:underline">Download</a>
                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-gray-500">Tidak ada data kehadiran yang cocok dengan filter.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-4">
                <?php echo e($kehadiran->links()); ?>

            </div>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#pegawai-select').select2({
                placeholder: "Cari atau pilih pegawai",
                allowClear: true,
                width: '100%' // Set lebar 100% agar responsif
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Management-Karyawan/resources/views/admin/kehadiran/index.blade.php ENDPATH**/ ?>