<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="p-6 pt-20">
        <div class="bg-white rounded-lg shadow p-6 space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border rounded-lg p-4">
                    <h3 class="font-bold text-lg"><?php echo e($meeting->judul); ?></h3>
                    <p class="text-sm text-gray-500">
                        Dibuat oleh: <?php echo e($meeting->pembuat->nama ?? '-'); ?> |
                        Peserta: <?php echo e($meeting->pesertas_count); ?>

                    </p>
                    <p class="text-sm">
                        Waktu: <?php echo e(\Carbon\Carbon::parse($meeting->waktu_mulai)->format('d M Y H:i')); ?>

                        - <?php echo e(\Carbon\Carbon::parse($meeting->waktu_selesai)->format('d M Y H:i')); ?>

                    </p>
                    <p class="text-sm">Lokasi: <?php echo e($meeting->lokasi); ?></p>
                    <a href="<?php echo e(route('pegawai.meeting.show', $meeting->id)); ?>"
                        class="text-blue-600 hover:underline text-sm">Detail</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500 text-center">Belum ada meeting yang dijadwalkan.</p>
            <?php endif; ?>

            <div class="mt-4">
                <?php echo e($meetings->links('vendor.pagination.tailwind')); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/faza/Internship/Management-Karyawan/resources/views/pegawai/meeting/index.blade.php ENDPATH**/ ?>