<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$classes = ($active ?? false)
    ? 'flex items-center w-full px-4 py-2 rounded-lg bg-white text-black text-sm font-bold 
       shadow-md relative
       before:content-[""] before:absolute before:left-0 before:top-0 before:h-full before:w-1 before:bg-blue-600'
    : 'flex items-center w-full px-4 py-2 rounded-lg text-gray-800 
       hover:bg-white hover:text-black text-sm font-semibold transition relative';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH /Users/faza/Internship/Management-Karyawan/resources/views/components/nav-link.blade.php ENDPATH**/ ?>