<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen bg-white p-10">
        <div class="max-w-4xl mx-auto space-y-8">
            <!-- Header -->
            <div>
                <h1 class="text-2xl font-semibold text-gray-900">Buat Pengumuman Baru</h1>
                <p class="text-gray-500 text-sm mt-1">
                    Isi detail pengumuman dan tentukan target penerimanya dengan jelas.
                </p>
            </div>

            <!-- Form Card -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
                <?php if($errors->any()): ?>
                    <div class="mb-6 p-4 bg-red-100 text-red-700 rounded-lg">
                        <ul class="list-disc pl-5 space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.pengumuman.store')); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>

                    <!-- Judul -->
                    <div>
                        <label for="judul" class="block text-sm font-medium text-gray-700 mb-1">
                            Judul Pengumuman
                        </label>
                        <input type="text" name="judul" id="judul"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                            value="<?php echo e(old('judul')); ?>" placeholder="Masukkan judul pengumuman..." required>
                    </div>

                    <!-- Isi -->
                    <div>
                        <label for="isi" class="block text-sm font-medium text-gray-700 mb-1">
                            Isi Pengumuman
                        </label>
                        <textarea name="isi" id="isi" rows="8"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                            placeholder="Tulis isi pengumuman di sini..."><?php echo e(old('isi')); ?></textarea>
                    </div>

                    <!-- Target Type -->
                    <div>
                        <label for="target_type" class="block text-sm font-medium text-gray-700 mb-1">
                            Tujukan Kepada
                        </label>
                        <select name="target_type" id="target_type"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                            required>
                            <option value="semua" <?php echo e(old('target_type') == 'semua' ? 'selected' : ''); ?>>Semua Pegawai</option>
                            <option value="divisi" <?php echo e(old('target_type') == 'divisi' ? 'selected' : ''); ?>>Divisi Tertentu</option>
                            <option value="tim" <?php echo e(old('target_type') == 'tim' ? 'selected' : ''); ?>>Tim Tertentu</option>
                            <option value="jabatan" <?php echo e(old('target_type') == 'jabatan' ? 'selected' : ''); ?>>Jabatan Tertentu</option>
                            <option value="pegawai" <?php echo e(old('target_type') == 'pegawai' ? 'selected' : ''); ?>>Pegawai Tertentu</option>
                        </select>
                    </div>

                    <!-- Target Spesifik -->
                    <div id="target-spesifik-wrapper" class="hidden space-y-5">
                        <!-- Divisi -->
                        <div id="divisi-container" class="target-container hidden">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Pilih Divisi</label>
                            <input type="search" id="divisi-search"
                                class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                                placeholder="Cari divisi...">
                            <div class="mt-3 border border-gray-200 rounded-lg max-h-48 overflow-y-auto">
                                <?php $__currentLoopData = $divisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="target-item flex items-center gap-3 p-2 border-b last:border-b-0 hover:bg-gray-50">
                                        <input type="checkbox" name="target_ids[]" value="<?php echo e($item->id); ?>"
                                            class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                        <span class="text-sm text-gray-700"><?php echo e($item->nama_divisi); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Tim -->
                        <div id="tim-container" class="target-container hidden">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Pilih Tim</label>
                            <input type="search" id="tim-search"
                                class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                                placeholder="Cari tim...">
                            <div class="mt-3 border border-gray-200 rounded-lg max-h-48 overflow-y-auto">
                                <?php $__currentLoopData = $tims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="target-item flex items-center gap-3 p-2 border-b last:border-b-0 hover:bg-gray-50">
                                        <input type="checkbox" name="target_ids[]" value="<?php echo e($item->id); ?>"
                                            class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                        <span class="text-sm text-gray-700"><?php echo e($item->nama_tim); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Jabatan -->
                        <div id="jabatan-container" class="target-container hidden">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Pilih Jabatan</label>
                            <input type="search" id="jabatan-search"
                                class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                                placeholder="Cari jabatan...">
                            <div class="mt-3 border border-gray-200 rounded-lg max-h-48 overflow-y-auto">
                                <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="target-item flex items-center gap-3 p-2 border-b last:border-b-0 hover:bg-gray-50">
                                        <input type="checkbox" name="target_ids[]" value="<?php echo e($item->id); ?>"
                                            class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                        <span class="text-sm text-gray-700"><?php echo e($item->nama_jabatan); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Pegawai -->
                        <div id="pegawai-container" class="target-container hidden">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Pilih Pegawai</label>
                            <input type="search" id="pegawai-search"
                                class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                                placeholder="Cari pegawai...">
                            <div class="mt-3 border border-gray-200 rounded-lg max-h-48 overflow-y-auto">
                                <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="target-item flex items-center gap-3 p-2 border-b last:border-b-0 hover:bg-gray-50">
                                        <input type="checkbox" name="target_ids[]" value="<?php echo e($item->id); ?>"
                                            class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                        <span class="text-sm text-gray-700"><?php echo e($item->nama); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <!-- Tombol Aksi -->
                    <div class="flex items-center justify-end gap-3 pt-4">
                        <a href="<?php echo e(route('admin.pengumuman.index')); ?>"
                            class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg text-sm font-medium">
                            Batal
                        </a>
                        <button type="submit"
                            class="px-4 py-2 bg-black hover:bg-gray-800 text-white rounded-lg text-sm font-medium">
                            Publikasikan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const targetTypeSelect = document.getElementById('target_type');
            const wrapper = document.getElementById('target-spesifik-wrapper');
            const containers = {
                divisi: document.getElementById('divisi-container'),
                tim: document.getElementById('tim-container'),
                jabatan: document.getElementById('jabatan-container'),
                pegawai: document.getElementById('pegawai-container'),
            };

            function showCorrectContainer() {
                const selectedType = targetTypeSelect.value;
                Object.values(containers).forEach(container => container.classList.add('hidden'));
                if (selectedType !== 'semua') {
                    wrapper.classList.remove('hidden');
                    if (containers[selectedType]) {
                        containers[selectedType].classList.remove('hidden');
                    }
                } else {
                    wrapper.classList.add('hidden');
                }
            }

            function setupSearch(inputId, containerId) {
                const searchInput = document.getElementById(inputId);
                const items = document.querySelectorAll(`#${containerId} .target-item`);
                searchInput?.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    items.forEach(item => {
                        const text = item.querySelector('span').textContent.toLowerCase();
                        item.style.display = text.includes(searchTerm) ? 'flex' : 'none';
                    });
                });
            }

            targetTypeSelect.addEventListener('change', showCorrectContainer);
            setupSearch('divisi-search', 'divisi-container');
            setupSearch('tim-search', 'tim-container');
            setupSearch('jabatan-search', 'jabatan-container');
            setupSearch('pegawai-search', 'pegawai-container');
            showCorrectContainer();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Management-Karyawan/resources/views/admin/pengumuman/create.blade.php ENDPATH**/ ?>