<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-white">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <h2 class="font-bold text-3xl text-gray-900 leading-tight">
                Dashboard Admin
            </h2>

            <!-- === GRID DASHBOARD === -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Card Total Pegawai -->
                <div class="bg-gray-100 rounded-xl shadow p-6 border border-gray-100">
                    <h3 class="text-sm font-bold text-gray-900 text-center">Active employee</h3>
                    <p class="mt-2 text-[50px] font-bold text-gray-900 text-center"><?php echo e($totalPegawai); ?></p>
                </div>

                <!-- Card Total Gaji -->
                <div class="bg-gray-100 rounded-xl shadow p-6 border border-gray-100">
                    <h3 class="text-sm font-bold text-gray-900 text-center">Total salary for the final period</h3>
                    <p class="mt-6 text-[30px] font-bold text-gray-900 text-center">
                        Rp <?php echo e(number_format($totalGaji, 0, ',', '.')); ?>

                    </p>
                </div>

                <!-- Card Chart Jabatan -->
                <div class="bg-gray-100 rounded-xl shadow p-6 border border-gray-100 flex flex-col items-center justify-center">
                    <h3 class="text-sm font-bold text-gray-900 mb-4">Employees per position</h3>
                    <div class="h-24 w-24 flex items-center justify-center">
                        <canvas id="jabatanChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- === ROW BAWAH: ACTIVITY + ANNOUNCEMENT === -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Aktivitas -->
                <div class="bg-gray-100 rounded-xl shadow p-6 border border-gray-100">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 border-b pb-2">New Activity</h3>
                    <ul class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="flex items-start space-x-3 pb-3 border-b border-gray-100 last:border-b-0 hover:bg-gray-50 transition duration-150 rounded-lg p-2">
                                <!-- Icon user -->
                                <div class="flex-shrink-0 pt-1">
                                    <div class="w-8 h-8 rounded-full bg-gray-200 text-gray-700 flex items-center justify-center">
                                        <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 2a4 4 0 100 8 4 4 0 000-8zm-6 14a6 6 0 1112 0H4z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                </div>

                                <!-- Detail aktivitas -->
                                <div>
                                    <p class="text-sm text-gray-900 font-medium leading-snug"><?php echo $item->keterangan; ?></p>
                                    <p class="text-xs text-gray-500 mt-1">
                                        <?php echo e(\Carbon\Carbon::parse($item->waktu)->diffForHumans()); ?>

                                    </p>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>
                                <p class="text-center text-gray-500 py-4 italic">Tidak ada aktivitas terbaru dalam 7 hari terakhir.</p>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Pengumuman -->
                <div class="bg-gray-100 rounded-xl shadow p-6 border border-gray-100">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-bold text-gray-700">Announcement</h3>
                        <a href="<?php echo e(route('admin.pengumuman.create')); ?>" class="inline-block bg-gray-900 font-bold hover:bg-gray-800 text-white px-4 py-2 rounded-full shadow text-sm">
                            Add New Announcement
                        </a>
                    </div>

                    <div class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $pengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="border rounded-lg p-4 bg-gray-200">
                            <div class="flex justify-between items-start">
                                <div clas> 
                                    <h4 class="font-bold text-lg text-gray-800"><?php echo e($pengumuman->judul); ?></h4>
                                    <p class="text-xs text-gray-500">
                                        Dipublikasikan oleh <?php echo e($pengumuman->pembuat->username ?? 'N/A'); ?> pada <?php echo e($pengumuman->created_at->format('d M Y, H:i')); ?>

                                    </p>
                                </div>
                                <form action="<?php echo e(route('admin.pengumuman.destroy', $pengumuman->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Hapus pengumuman ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-700 text-sm">&times; Hapus</button>
                                </form>
                            </div>
                            <div class="prose max-w-none mt-2 text-gray-700">
                                <?php echo $pengumuman->isi; ?>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-8 text-gray-500">
                            <p>Belum ada pengumuman yang dibuat.</p>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-4">
                        <?php echo e($pengumumans->links('vendor.pagination.tailwind')); ?>

                    </div>
                </div>

                <!-- CARD MEETING -->
                <div class="bg-gray-100 rounded-xl shadow p-6 border border-gray-100 w-full col-span-full">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-bold text-gray-700">Meeting Schedule</h3>
                        <a href="<?php echo e(route('admin.meeting.create')); ?>" 
                        class="inline-block bg-gray-900 font-bold hover:bg-gray-800 text-white px-4 py-2 rounded-full shadow text-sm">
                            Add New Meeting
                        </a>
                    </div>

                    <!-- Notifikasi -->
                    <?php if(session('success')): ?>
                        <div class="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Tabel -->
                    <div class="overflow-x-auto">
                        <table class="min-w-full border border-gray-200 rounded">
                            <thead class="bg-gray-200">
                                <tr>
                                    <th class="border-b px-4 py-2 text-left">Judul Meeting</th>
                                    <th class="border-b px-4 py-2 text-left">Jadwal</th>
                                    <th class="border-b px-4 py-2 text-left">Lokasi</th>
                                    <th class="border-b px-4 py-2 text-left">Dibuat Oleh</th>
                                    <th class="border-b px-4 py-2 text-center">Jumlah Peserta</th>
                                    <th class="border-b px-4 py-2 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="border-b px-4 py-2 font-medium"><?php echo e($meeting->judul); ?></td>
                                        <td class="border-b px-4 py-2 text-sm">
                                            <?php echo e(\Carbon\Carbon::parse($meeting->waktu_mulai)->format('d M Y, H:i')); ?>

                                        </td>
                                        <td class="border-b px-4 py-2"><?php echo e($meeting->lokasi); ?></td>
                                        <td class="border-b px-4 py-2"><?php echo e($meeting->pembuat->nama ?? 'N/A'); ?></td>
                                        <td class="border-b px-4 py-2 text-center"><?php echo e($meeting->pesertas_count); ?></td>
                                        <td class="border-b px-4 py-2 text-center" style="width: 150px;">
                                            <a href="<?php echo e(route('admin.meeting.edit', $meeting->id)); ?>" 
                                            class="text-yellow-600 hover:text-yellow-900 mr-3">Edit</a>
                                            <form action="<?php echo e(route('admin.meeting.destroy', $meeting->id)); ?>" 
                                                method="POST" 
                                                class="inline" 
                                                onsubmit="return confirm('Hapus meeting ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="text-red-600 hover:text-red-900">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4 text-gray-500">
                                            Belum ada meeting yang dijadwalkan.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <div class="mt-4">
                            <?php echo e($meetings->links('vendor.pagination.tailwind')); ?>

                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let jabatanLabels = <?php echo json_encode(array_keys($jabatanData)); ?>;
            let jabatanValues = <?php echo json_encode(array_values($jabatanData)); ?>;

            if (jabatanLabels.length > 0) {
                new Chart(document.getElementById("jabatanChart"), {
                    type: "pie",
                    data: {
                        labels: jabatanLabels,
                        datasets: [{
                            data: jabatanValues,
                            backgroundColor: [
                                "#9CA3AF", 
                                "#6B7280", 
                                "#111827" 
                            ],
                            borderWidth: 2,
                            borderColor: "#fff"
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        }
                    }
                });
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Management-Karyawan/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>