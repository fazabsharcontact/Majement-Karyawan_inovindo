<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6">
                
                <div class="mb-6">
                    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                        Tambah Data Gaji
                    </h2>
                    <p class="text-gray-500 text-sm mt-1">
                        Lengkapi informasi gaji pegawai berikut secara lengkap dan teliti.
                    </p>
                </div>

                
                <?php if($errors->any()): ?>
                    <div class="mb-4 p-4 bg-red-100 text-red-700 rounded">
                        <ul class="list-disc pl-5">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($err); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form id="form-gaji" action="<?php echo e(route('admin.gaji.store')); ?>" method="POST" class="space-y-6">
                    <?php echo csrf_field(); ?>

                    
                    <div class="bg-gray-50 p-6 rounded-lg border border-gray-200">
                        <h3 class="text-lg font-semibold border-b pb-2 mb-4 text-gray-800">Informasi Utama</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                            <div>
                                <label for="pegawai_id" class="block font-medium text-sm text-gray-700">Pegawai</label>
                                <select name="pegawai_id" id="pegawai_id" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" required>
                                    <option value="">-- Pilih Pegawai --</option>
                                    <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>" 
                                                data-gaji-pokok="<?php echo e($p->gaji_pokok); ?>"
                                                data-nama-bank="<?php echo e($p->nama_bank ?? ''); ?>"
                                                data-nomor-rekening="<?php echo e($p->nomor_rekening ?? ''); ?>">
                                            <?php echo e($p->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label for="bulan" class="block font-medium text-sm text-gray-700">Bulan</label>
                                <select name="bulan" id="bulan" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" required>
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e(date('n') == $i ? 'selected' : ''); ?>>
                                            <?php echo e(\Carbon\Carbon::create()->month($i)->format('F')); ?>

                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div>
                                <label for="tahun" class="block font-medium text-sm text-gray-700">Tahun</label>
                                <input type="number" name="tahun" id="tahun" 
                                       class="border-gray-300 rounded-md shadow-sm mt-1 w-full" 
                                       value="<?php echo e(date('Y')); ?>" required>
                            </div>
                            <div>
                                <label for="gaji_pokok" class="block font-medium text-sm text-gray-700">Gaji Pokok (Rp)</label>
                                <input type="number" name="gaji_pokok" id="gaji_pokok" 
                                       class="border-gray-300 rounded-md shadow-sm mt-1 w-full" 
                                       placeholder="Pilih pegawai..." required>
                            </div>
                        </div>

                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-gray-200">
                            <div>
                                <label for="nama_bank" class="block font-medium text-sm text-gray-700">Nama Bank</label>
                                <input type="text" id="nama_bank" 
                                       class="bg-gray-100 border-gray-300 rounded-md shadow-sm mt-1 w-full" 
                                       placeholder="Pilih pegawai untuk melihat" readonly>
                            </div>
                            <div>
                                <label for="nomor_rekening" class="block font-medium text-sm text-gray-700">Nomor Rekening</label>
                                <input type="text" id="nomor_rekening" 
                                       class="bg-gray-100 border-gray-300 rounded-md shadow-sm mt-1 w-full" 
                                       placeholder="Pilih pegawai untuk melihat" readonly>
                            </div>
                        </div>
                    </div>

                    
                    <div class="bg-gray-50 p-6 rounded-lg border border-gray-200">
                        <div class="flex justify-between items-center border-b pb-2 mb-4">
                            <h3 class="text-lg font-semibold text-gray-800">Tunjangan</h3>
                            <button type="button" id="add-tunjangan" 
                                    class="bg-gray-900 hover:bg-gray-800 text-white px-3 py-1 rounded-lg text-sm">
                                + Tambah Tunjangan
                            </button>
                        </div>
                        <div id="tunjangan-container" class="space-y-3"></div>
                    </div>

                    
                    <div class="bg-gray-50 p-6 rounded-lg border border-gray-200">
                        <div class="flex justify-between items-center border-b pb-2 mb-4">
                            <h3 class="text-lg font-semibold text-gray-800">Potongan</h3>
                            <button type="button" id="add-potongan" 
                                    class="bg-gray-900 hover:bg-gray-800 text-white px-3 py-1 rounded-lg text-sm">
                                + Tambah Potongan
                            </button>
                        </div>
                        <div id="potongan-container" class="space-y-3"></div>
                    </div>

                    
                    <div class="bg-white p-6 rounded-lg shadow-inner border border-gray-200">
                        <h3 class="text-lg font-semibold border-b pb-2 mb-4 text-gray-800">Ringkasan Gaji</h3>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between">
                                <span>Gaji Pokok:</span>
                                <span id="summary-gaji-pokok">Rp 0</span>
                            </div>
                            <div class="flex justify-between">
                                <span>Total Tunjangan:</span>
                                <span id="summary-total-tunjangan" class="text-green-600">Rp 0</span>
                            </div>
                            <div class="flex justify-between">
                                <span>Total Potongan:</span>
                                <span id="summary-total-potongan" class="text-red-600">Rp 0</span>
                            </div>
                            <div class="flex justify-between font-bold text-base border-t pt-2 mt-2">
                                <span>Gaji Bersih (Estimasi):</span>
                                <span id="summary-gaji-bersih">Rp 0</span>
                            </div>
                        </div>
                    </div>

                    
                    <div class="flex items-center gap-2 pt-4">
                        <button type="submit" 
                                class="bg-gray-900 hover:bg-gray-800 text-white px-4 py-2 rounded-lg shadow">
                            Simpan
                        </button>
                        <a href="<?php echo e(route('admin.gaji.index')); ?>" 
                           class="bg-gray-200 hover:bg-gray-300 text-black px-4 py-2 rounded-lg shadow">
                            Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const masterTunjangans = <?php echo json_encode($masterTunjangans, 15, 512) ?>;
            const masterPotongans = <?php echo json_encode($masterPotongans, 15, 512) ?>;
            const form = document.getElementById('form-gaji');
            
            const formatter = new Intl.NumberFormat('id-ID', {
                style: 'currency', currency: 'IDR', minimumFractionDigits: 0
            });

            function calculateTotals() {
                const gajiPokok = parseFloat(document.getElementById('gaji_pokok').value) || 0;
                let totalTunjangan = 0;
                let totalPotongan = 0;
                document.querySelectorAll('#tunjangan-container .jumlah-input').forEach(input => totalTunjangan += parseFloat(input.value) || 0);
                document.querySelectorAll('#potongan-container .jumlah-input').forEach(input => totalPotongan += parseFloat(input.value) || 0);
                const gajiBersih = gajiPokok + totalTunjangan - totalPotongan;
                document.getElementById('summary-gaji-pokok').textContent = formatter.format(gajiPokok);
                document.getElementById('summary-total-tunjangan').textContent = formatter.format(totalTunjangan);
                document.getElementById('summary-total-potongan').textContent = formatter.format(totalPotongan);
                document.getElementById('summary-gaji-bersih').textContent = formatter.format(gajiBersih);
            }

            document.getElementById('gaji_pokok').addEventListener('input', calculateTotals);

            // PERUBAHAN 2: Sempurnakan event listener
            document.getElementById('pegawai_id').addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                
                // Ambil semua data dari atribut
                const gajiPokok = selectedOption.getAttribute('data-gaji-pokok');
                const namaBank = selectedOption.getAttribute('data-nama-bank');
                const nomorRekening = selectedOption.getAttribute('data-nomor-rekening');
                
                // Isi field Gaji Pokok
                document.getElementById('gaji_pokok').value = gajiPokok || '';

                // Isi field Informasi Bank
                document.getElementById('nama_bank').value = namaBank || '';
                document.getElementById('nomor_rekening').value = nomorRekening || '';

                // Hitung ulang total
                calculateTotals();
            });

            let tunjanganIndex = 0;
            let potonganIndex = 0;
            
            function handleDropdownChange(event) {
                const selectedOption = event.target.options[event.target.selectedIndex];
                const defaultValue = selectedOption.getAttribute('data-default');
                const jumlahInput = event.target.closest('.grid').querySelector('.jumlah-input');
                if (defaultValue) {
                    jumlahInput.value = defaultValue;
                } else {
                    jumlahInput.value = '';
                }
                calculateTotals();
            }

            function addNewRow(type) {
                const isTunjangan = type === 'tunjangan';
                const container = document.getElementById(isTunjangan ? 'tunjangan-container' : 'potongan-container');
                const masterData = isTunjangan ? masterTunjangans : masterPotongans;
                const index = isTunjangan ? tunjanganIndex++ : potonganIndex++;
                const namePrefix = isTunjangan ? 'tunjangans' : 'potongans';
                const masterIdName = isTunjangan ? 'master_tunjangan_id' : 'master_potongan_id';
                const masterName = isTunjangan ? 'nama_tunjangan' : 'nama_potongan';
                const selectClass = isTunjangan ? 'tunjangan-select' : 'potongan-select';
                const newRow = document.createElement('div');
                newRow.classList.add('grid', 'grid-cols-1', 'md:grid-cols-3', 'gap-4', 'items-center', 'p-2', 'border', 'rounded-md');
                let optionsHtml = masterData.map(item => `<option value="${item.id}" data-default="${item.jumlah_default || ''}">${item[masterName]}</option>`).join('');
                newRow.innerHTML = `
                    <div>
                        <select name="${namePrefix}[${index}][${masterIdName}]" class="${selectClass} border-gray-300 rounded-md shadow-sm mt-1 w-full" required>
                            <option value="">-- Pilih ${isTunjangan ? 'Tunjangan' : 'Potongan'} --</option>
                            ${optionsHtml}
                        </select>
                    </div>
                    <div>
                        <input type="number" name="${namePrefix}[${index}][jumlah]" class="jumlah-input border-gray-300 rounded-md shadow-sm mt-1 w-full" placeholder="Jumlah (Rp)" required>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="text" name="${namePrefix}[${index}][keterangan]" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" placeholder="Keterangan">
                        <button type="button" class="remove-row bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">&times;</button>
                    </div>
                `;
                container.appendChild(newRow);
                
                newRow.querySelector(`.${selectClass}`).addEventListener('change', handleDropdownChange);
                newRow.querySelector('.jumlah-input').addEventListener('input', calculateTotals);
                newRow.querySelector('.remove-row').addEventListener('click', function() {
                    newRow.remove(); 
                    calculateTotals();
                });
                
                calculateTotals();
            }
            
            document.getElementById('add-tunjangan').addEventListener('click', () => addNewRow('tunjangan'));
            document.getElementById('add-potongan').addEventListener('click', () => addNewRow('potongan'));

            // Logika untuk popup konfirmasi
            const modal = document.getElementById('confirmation-modal');
            const confirmYes = document.getElementById('confirm-yes');
            const confirmNo = document.getElementById('confirm-no');
            const modalTitle = document.getElementById('modal-title');
            const modalMessage = document.getElementById('modal-message');
            const warningPegawai = document.getElementById('warning-pegawai');
            const pegawaiList = document.getElementById('pegawai-list');

            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                const formData = new FormData(form);
                const pegawaiId = formData.get('pegawai_id');

                if (!pegawaiId) {
                    // Simple browser alert for quick feedback, can be replaced with a nicer modal
                    const customAlert = document.createElement('div');
                    customAlert.innerHTML = `
                        <div style="position: fixed; top: 1rem; right: 1rem; background-color: #f8d7da; color: #721c24; padding: 1rem; border-radius: 0.25rem; border: 1px solid #f5c6cb; z-index: 1000;">
                            Silakan pilih pegawai terlebih dahulu.
                        </div>
                    `;
                    document.body.appendChild(customAlert);
                    setTimeout(() => customAlert.remove(), 3000);
                    return;
                }
                
                modalTitle.textContent = 'Konfirmasi Penyimpanan';
                modalMessage.textContent = 'Apakah Anda yakin ingin menyimpan data gaji ini?';
                warningPegawai.classList.add('hidden');
                pegawaiList.innerHTML = '';
                modal.classList.remove('hidden');
                
                try {
                    const response = await fetch("<?php echo e(route('admin.gaji.cek')); ?>", {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value,
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            pegawai_id: pegawaiId,
                            bulan: formData.get('bulan'),
                            tahun: formData.get('tahun')
                        })
                    });
                    
                    const result = await response.json();

                    if (result.exists && result.pegawai) {
                        modalTitle.textContent = 'Peringatan: Data Gaji Ganda';
                        modalMessage.textContent = 'Pegawai berikut sudah memiliki data gaji pada periode ini. Apakah Anda yakin ingin membuat data gaji baru?';
                        warningPegawai.classList.remove('hidden');
                        pegawaiList.innerHTML = `<li>${result.pegawai.nama} (${result.pegawai.jabatan?.nama_jabatan || ''})</li>`;
                    }
                } catch (error) {
                    console.error('Gagal melakukan pengecekan:', error);
                }
            });

            confirmYes.addEventListener('click', () => form.submit());
            confirmNo.addEventListener('click', () => modal.classList.add('hidden'));

            calculateTotals();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Management-Karyawan/resources/views/admin/gaji/create.blade.php ENDPATH**/ ?>