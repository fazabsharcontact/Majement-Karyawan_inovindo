<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen bg-white p-10">
        <div class="max-w-4xl mx-auto space-y-8">
            <!-- Header -->
            <div>
                <h1 class="text-2xl font-semibold text-gray-900">Jadwalkan Meeting Baru</h1>
                <p class="text-gray-500 text-sm mt-1">
                    Isi detail meeting dan tentukan peserta serta penanggung jawabnya dengan jelas.
                </p>
            </div>

            <!-- Form Card -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
                <?php if($errors->any()): ?>
                    <div class="mb-6 p-4 bg-red-100 text-red-700 rounded-lg">
                        <ul class="list-disc pl-5 space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.meeting.store')); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>

                    <!-- Judul -->
                    <div>
                        <label for="judul" class="block text-sm font-medium text-gray-700 mb-1">
                            Judul Meeting
                        </label>
                        <input type="text" name="judul" id="judul"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                            value="<?php echo e(old('judul')); ?>" placeholder="Masukkan judul meeting..." required autofocus>
                    </div>

                    <!-- Waktu -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="waktu_mulai" class="block text-sm font-medium text-gray-700 mb-1">
                                Waktu Mulai
                            </label>
                            <input type="datetime-local" name="waktu_mulai" id="waktu_mulai"
                                class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                                value="<?php echo e(old('waktu_mulai')); ?>" required>
                        </div>
                        <div>
                            <label for="waktu_selesai" class="block text-sm font-medium text-gray-700 mb-1">
                                Waktu Selesai
                            </label>
                            <input type="datetime-local" name="waktu_selesai" id="waktu_selesai"
                                class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                                value="<?php echo e(old('waktu_selesai')); ?>" required>
                        </div>
                    </div>

                    <!-- Lokasi -->
                    <div>
                        <label for="lokasi" class="block text-sm font-medium text-gray-700 mb-1">
                            Lokasi
                        </label>
                        <input type="text" name="lokasi" id="lokasi"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                            placeholder="Masukkan lokasi meeting..." value="<?php echo e(old('lokasi')); ?>" required>
                    </div>

                    <!-- Penanggung Jawab -->
                    <div>
                        <label for="pembuat_id" class="block text-sm font-medium text-gray-700 mb-1">
                            Penanggung Jawab
                        </label>
                        <select name="pembuat_id" id="pembuat_id"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                            required>
                            <option value="">-- Pilih Penanggung Jawab --</option>
                            <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pegawai->id); ?>" <?php echo e(old('pembuat_id') == $pegawai->id ? 'selected' : ''); ?>>
                                    <?php echo e($pegawai->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Deskripsi -->
                    <div>
                        <label for="deskripsi" class="block text-sm font-medium text-gray-700 mb-1">
                            Deskripsi (Opsional)
                        </label>
                        <textarea name="deskripsi" id="deskripsi" rows="5"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2"
                            placeholder="Tulis deskripsi meeting..."><?php echo e(old('deskripsi')); ?></textarea>
                    </div>

                    <!-- Peserta -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Peserta Meeting</label>
                        <input type="search" id="peserta-search"
                            class="w-full border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-lg shadow-sm text-sm px-3 py-2 mb-3"
                            placeholder="Cari pegawai...">
                        <div id="peserta-list"
                            class="border border-gray-200 rounded-lg max-h-60 overflow-y-auto">
                            <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="peserta-item flex items-center gap-3 p-2 border-b last:border-b-0 hover:bg-gray-50">
                                    <input type="checkbox" name="peserta_ids[]" value="<?php echo e($pegawai->id); ?>"
                                        class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                    <span class="text-sm text-gray-700"><?php echo e($pegawai->nama); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Tombol -->
                    <div class="flex items-center justify-end gap-3 pt-4">
                        <a href="<?php echo e(route('admin.meeting.index')); ?>"
                            class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg text-sm font-medium">
                            Batal
                        </a>
                        <button type="submit"
                            class="px-4 py-2 bg-black hover:bg-gray-800 text-white rounded-lg text-sm font-medium">
                            Simpan Jadwal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('peserta-search');
            const pesertaItems = document.querySelectorAll('.peserta-item');
            const pembuatSelect = document.getElementById('pembuat_id');
            const pesertaCheckboxes = document.querySelectorAll('input[name="peserta_ids[]"]');

            function syncPembuatToPeserta() {
                const pembuatId = pembuatSelect.value;
                pesertaCheckboxes.forEach(checkbox => {
                    checkbox.disabled = false;
                    if (checkbox.value === pembuatId) {
                        checkbox.checked = true;
                        checkbox.disabled = true;
                    }
                });
            }

            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                pesertaItems.forEach(item => {
                    const nama = item.querySelector('span').textContent.toLowerCase();
                    item.style.display = nama.includes(searchTerm) ? 'flex' : 'none';
                });
            });

            pembuatSelect.addEventListener('change', syncPembuatToPeserta);
            syncPembuatToPeserta();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Management-Karyawan/resources/views/admin/meeting/create.blade.php ENDPATH**/ ?>