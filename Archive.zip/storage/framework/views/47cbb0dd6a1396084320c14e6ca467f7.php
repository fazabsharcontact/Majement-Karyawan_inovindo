<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen bg-white p-10">
        <div class="max-w-5xl mx-auto space-y-8">
            <!-- Header -->
            <div>
                <h1 class="text-2xl font-semibold text-gray-900">Edit Data Gaji untuk: <?php echo e($gaji->pegawai->nama); ?></h1>
                <p class="text-gray-500 text-sm mt-1">
                    Perbarui detail gaji pegawai termasuk tunjangan dan potongan secara lengkap.
                </p>
            </div>

            <!-- Form Card -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
                <form id="form-gaji-edit" action="<?php echo e(route('admin.gaji.update', $gaji->id)); ?>" method="POST" class="space-y-8">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Informasi Utama -->
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800 border-b pb-3 mb-4">Informasi Utama</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <div>
                                <label for="pegawai_id" class="block font-medium text-sm text-gray-700">Pegawai</label>
                                <select name="pegawai_id" id="pegawai_id" class="border-gray-300 rounded-md shadow-sm mt-1 w-full bg-gray-100" required disabled>
                                    <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" data-gaji-pokok="<?php echo e($p->gaji_pokok); ?>" <?php echo e($gaji->pegawai_id == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" name="pegawai_id" value="<?php echo e($gaji->pegawai_id); ?>">
                            </div>

                            <div>
                                <label for="bulan" class="block font-medium text-sm text-gray-700">Bulan</label>
                                <select name="bulan" id="bulan" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" required>
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e(old('bulan', $gaji->bulan) == $i ? 'selected' : ''); ?>>
                                        <?php echo e(\Carbon\Carbon::create()->month($i)->format('F')); ?>

                                    </option>
                                    <?php endfor; ?>
                                </select>
                            </div>

                            <div>
                                <label for="tahun" class="block font-medium text-sm text-gray-700">Tahun</label>
                                <input type="number" name="tahun" id="tahun" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" value="<?php echo e(old('tahun', $gaji->tahun)); ?>" required>
                            </div>

                            <div>
                                <label for="gaji_pokok" class="block font-medium text-sm text-gray-700">Gaji Pokok (Rp)</label>
                                <input type="number" name="gaji_pokok" id="gaji_pokok" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" value="<?php echo e(old('gaji_pokok', $gaji->gaji_pokok)); ?>" required>
                            </div>
                        </div>
                    </div>

                    <!-- Tunjangan -->
                    <div>
                        <div class="flex justify-between items-center border-b pb-3 mb-4">
                            <h3 class="text-lg font-semibold text-gray-800">Tunjangan</h3>
                            <button type="button" id="add-tunjangan" class="bg-gray-200 hover:bg-gray-300 text-black px-3 py-1.5 rounded-md text-sm shadow-sm">
                                + Tambah Tunjangan
                            </button>
                        </div>
                        <div id="tunjangan-container" class="space-y-3">
                            <?php $__currentLoopData = $gaji->tunjanganDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-center p-3 border border-gray-200 rounded-md bg-gray-50">
                                <div>
                                    <select name="tunjangans[<?php echo e($index); ?>][master_tunjangan_id]" class="tunjangan-select border-gray-300 rounded-md shadow-sm mt-1 w-full" required>
                                        <option value="">-- Pilih Tunjangan --</option>
                                        <?php $__currentLoopData = $masterTunjangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($t->id); ?>" data-default="<?php echo e($t->jumlah_default ?? ''); ?>" <?php echo e($detail->master_tunjangan_id == $t->id ? 'selected' : ''); ?>>
                                            <?php echo e($t->nama_tunjangan); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div>
                                    <input type="number" name="tunjangans[<?php echo e($index); ?>][jumlah]" class="jumlah-input border-gray-300 rounded-md shadow-sm mt-1 w-full" placeholder="Jumlah (Rp)" value="<?php echo e($detail->jumlah); ?>" required>
                                </div>
                                <div class="flex items-center gap-2">
                                    <input type="text" name="tunjangans[<?php echo e($index); ?>][keterangan]" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" placeholder="Keterangan (Opsional)" value="<?php echo e($detail->keterangan); ?>">
                                    <button type="button" class="remove-row bg-gray-900 hover:bg-gray-800 text-white px-3 py-1 rounded text-sm shadow-sm">&times;</button>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Potongan -->
                    <div>
                        <div class="flex justify-between items-center border-b pb-3 mb-4">
                            <h3 class="text-lg font-semibold text-gray-800">Potongan</h3>
                            <button type="button" id="add-potongan" class="bg-gray-200 hover:bg-gray-300 text-black px-3 py-1.5 rounded-md text-sm shadow-sm">
                                + Tambah Potongan
                            </button>
                        </div>
                        <div id="potongan-container" class="space-y-3">
                            <?php $__currentLoopData = $gaji->potonganDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-center p-3 border border-gray-200 rounded-md bg-gray-50">
                                <div>
                                    <select name="potongans[<?php echo e($index); ?>][master_potongan_id]" class="potongan-select border-gray-300 rounded-md shadow-sm mt-1 w-full" required>
                                        <option value="">-- Pilih Potongan --</option>
                                        <?php $__currentLoopData = $masterPotongans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>" data-default="<?php echo e($p->jumlah_default ?? ''); ?>" <?php echo e($detail->master_potongan_id == $p->id ? 'selected' : ''); ?>>
                                            <?php echo e($p->nama_potongan); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div>
                                    <input type="number" name="potongans[<?php echo e($index); ?>][jumlah]" class="jumlah-input border-gray-300 rounded-md shadow-sm mt-1 w-full" placeholder="Jumlah (Rp)" value="<?php echo e($detail->jumlah); ?>" required>
                                </div>
                                <div class="flex items-center gap-2">
                                    <input type="text" name="potongans[<?php echo e($index); ?>][keterangan]" class="border-gray-300 rounded-md shadow-sm mt-1 w-full" placeholder="Keterangan (Opsional)" value="<?php echo e($detail->keterangan); ?>">
                                    <button type="button" class="remove-row bg-gray-900 hover:bg-gray-800 text-white px-3 py-1 rounded text-sm shadow-sm">&times;</button>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Ringkasan -->
                    <div class="bg-gray-50 border border-gray-200 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-800 border-b pb-3 mb-4">Ringkasan Gaji</h3>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between"><span>Gaji Pokok:</span> <span id="summary-gaji-pokok">Rp 0</span></div>
                            <div class="flex justify-between"><span>Total Tunjangan:</span> <span id="summary-total-tunjangan" class="text-green-600">Rp 0</span></div>
                            <div class="flex justify-between"><span>Total Potongan:</span> <span id="summary-total-potongan" class="text-red-600">Rp 0</span></div>
                            <div class="flex justify-between font-semibold text-base border-t pt-3 mt-2"><span>Gaji Bersih (Estimasi):</span> <span id="summary-gaji-bersih">Rp 0</span></div>
                        </div>
                    </div>

                    <!-- Tombol -->
                    <div class="flex items-center justify-end gap-3 pt-4">
                        <a href="<?php echo e(route('admin.gaji.index')); ?>" class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg text-sm font-medium">
                            Batal
                        </a>
                        <button type="submit" class="px-4 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-lg text-sm font-medium">
                            Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <script>
        // (salin seluruh script JavaScript dari versi sebelumnya, tanpa diubah)
        document.addEventListener('DOMContentLoaded', function() {
            const masterTunjangans = <?php echo json_encode($masterTunjangans, 15, 512) ?>;
            const masterPotongans = <?php echo json_encode($masterPotongans, 15, 512) ?>;
            const formatter = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 });

            function calculateTotals() {
                const gajiPokok = parseFloat(document.getElementById('gaji_pokok').value) || 0;
                let totalTunjangan = 0;
                let totalPotongan = 0;
                document.querySelectorAll('#tunjangan-container .jumlah-input').forEach(i => totalTunjangan += parseFloat(i.value) || 0);
                document.querySelectorAll('#potongan-container .jumlah-input').forEach(i => totalPotongan += parseFloat(i.value) || 0);
                const bersih = gajiPokok + totalTunjangan - totalPotongan;
                document.getElementById('summary-gaji-pokok').textContent = formatter.format(gajiPokok);
                document.getElementById('summary-total-tunjangan').textContent = formatter.format(totalTunjangan);
                document.getElementById('summary-total-potongan').textContent = formatter.format(totalPotongan);
                document.getElementById('summary-gaji-bersih').textContent = formatter.format(bersih);
            }

            function setupRow(el) {
                el.querySelector('.jumlah-input')?.addEventListener('input', calculateTotals);
                el.querySelector('.remove-row')?.addEventListener('click', () => { el.remove(); calculateTotals(); });
            }

            document.querySelectorAll('#tunjangan-container > div, #potongan-container > div').forEach(setupRow);
            document.getElementById('gaji_pokok').addEventListener('input', calculateTotals);
            calculateTotals();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/faza/Management-Karyawan/resources/views/admin/gaji/edit.blade.php ENDPATH**/ ?>